// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// CustomException class that extends from std::exception
// Custom exception class to demonstrate how user-defined exceptions can be created
struct CustomException : public std::exception
{
	// Override the what() method to return a custom exception message
	virtual const char* what() const throw()
	{
		// Return custom exception message
		return "Test of standard exception message";
	}
};

bool do_even_more_custom_application_logic()
{
	// TODO: Throw any standard exception
	// This throws a standard exception (std::bad_exception) for demonstration purposes
	throw std::bad_exception();

	// Code below this line will never be reached because of the exception thrown above
	std::cout << "Running Even More Custom Application Logic." << std::endl;

	return true;
}

void do_custom_application_logic()
{
	// TODO: Wrap the call to do_even_more_custom_application_logic()
	// with an exception handler that catches std::exception, displays
	// a message and the exception.what(), then continues processing
	std::cout << "Running Custom Application Logic." << std::endl;

	try
	{
		// Call the function that might throw an exception
		if (do_even_more_custom_application_logic())
		{
			std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
		}
	}
	catch (const std::exception& exception)
	{
		// Catch any standard exception and display the message
		std::cerr << "Exception message: " << exception.what() << std::endl;
	}

	// TODO: Throw a custom exception derived from std::exception
	// and catch it explicitly in main
	throw CustomException(); // This will throw the custom exception

	std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
	// TODO: Throw an exception to deal with divide by zero errors using
	// a standard C++ defined exception
	// Check if the denominator is zero and throw an exception if true
	if (den == 0)
	{
		throw std::runtime_error("Divide by zero error"); // Throw runtime_error
	}
	return (num / den); // Return the division result if no exception occurred
}

void do_division() noexcept
{
	// TODO: Create an exception handler to capture ONLY the exception thrown
	// by divide.
	// This function demonstrates handling only division-related exceptions

	float numerator = 10.0f;
	float denominator = 0;

	try
	{
		// Attempt to perform the division operation
		auto result = divide(numerator, denominator);
		std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
	}
	catch (const std::exception& exception)
	{
		// Catch the exception thrown by divide (in this case, std::runtime_error)
		std::cerr << "Exception message: " << exception.what() << std::endl;
	}
}

int main()
{
	try
	{
		// Main function where exception handling is wrapped
		std::cout << "Exceptions Tests" << std::endl;

		// Call the division logic
		do_division();
		// Call the custom application logic
		do_custom_application_logic();
	}
	catch (const CustomException& exception)
	{
		// Catch the custom exception and display the message
		std::cerr << "Exception message: " << exception.what() << std::endl;
	}
	catch (const std::exception& exception)
	{
		// Catch other standard exceptions and display the message
		std::cerr << "Exception message: " << exception.what() << std::endl;
	}
	catch (...)
	{
		// Catch all uncaught exceptions (generic handler)
		// This will prevent the program from crashing abruptly if an unexpected exception occurs
	}
}
